﻿

namespace Domain.MainBoundedContext.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.Samples.NLayerApp.Domain.MainBoundedContext.ERPModule.Aggregates.ProductAgg;
    using System.ComponentModel.DataAnnotations;

    [TestClass()]
    public class ProductAggTests
    {
        [TestMethod()]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CannotCreateAProductWithNullTitle()
        {
            //Arrange and Act
            var product = new Book(null, "the description");
        }
        [TestMethod()]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CannotCreateAProductWithNullDescription()
        {
            //Arrange and Act
            var product = new Book("the title", null);
        }
        [TestMethod()]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CannotCreateAProductWithEmptyTitle()
        {
            //Arrange and Act
            var product = new Book(string.Empty, "the description");
        }
        [TestMethod()]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CannotCreateAProductWithEmptyDescription()
        {
            //Arrange and Act
            var product = new Book("the title", string.Empty);
        }
        [TestMethod()]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CannotCreateAProductWithWhitespaceTitle()
        {
            //Arrange and Act
            var product = new Book(" ", "the description");
        }
        [TestMethod()]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CannotCreateAProductWithWhitespaceDescription()
        {
            //Arrange and Act
            var product = new Book("the title", " ");
        }
    }
}
