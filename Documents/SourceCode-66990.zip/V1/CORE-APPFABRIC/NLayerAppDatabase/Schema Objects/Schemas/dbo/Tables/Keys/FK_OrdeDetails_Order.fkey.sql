﻿ALTER TABLE [dbo].[OrderDetails]
    ADD CONSTRAINT [FK_OrdeDetails_Order] FOREIGN KEY ([OrderId]) REFERENCES [dbo].[Order] ([OrderId]) ON DELETE NO ACTION ON UPDATE NO ACTION;

