﻿ALTER TABLE [dbo].[Customer]
    ADD CONSTRAINT [DF_Customer_IsEnabled] DEFAULT ((1)) FOR [IsEnabled];



