﻿CREATE TABLE [dbo].[Software] (
    [ProductId]   INT            NOT NULL,
    [LicenseCode] NVARCHAR (200) COLLATE Modern_Spanish_CI_AS NOT NULL
);

