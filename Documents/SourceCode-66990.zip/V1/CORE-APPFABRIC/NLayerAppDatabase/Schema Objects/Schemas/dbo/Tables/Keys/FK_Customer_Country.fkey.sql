﻿ALTER TABLE [dbo].[Customer]
    ADD CONSTRAINT [FK_Customer_Country] FOREIGN KEY ([CountryId]) REFERENCES [dbo].[Country] ([CountryId]) ON DELETE NO ACTION ON UPDATE NO ACTION;

