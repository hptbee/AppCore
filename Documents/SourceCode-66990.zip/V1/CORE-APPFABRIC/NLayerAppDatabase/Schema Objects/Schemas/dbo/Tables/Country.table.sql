﻿CREATE TABLE [dbo].[Country] (
    [CountryId]   INT            IDENTITY (1, 1) NOT NULL,
    [CountryName] NVARCHAR (100) COLLATE Modern_Spanish_CI_AS NULL
);

