﻿CREATE TABLE [dbo].[Book] (
    [ProductId] INT            NOT NULL,
    [Publisher] NVARCHAR (200) COLLATE Modern_Spanish_CI_AS NOT NULL
);

